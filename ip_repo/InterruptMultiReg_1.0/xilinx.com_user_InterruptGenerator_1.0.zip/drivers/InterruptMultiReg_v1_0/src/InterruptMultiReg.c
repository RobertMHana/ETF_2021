

/***************************** Include Files *******************************/
#include "InterruptMultiReg.h"

/************************** Function Definitions ***************************/
