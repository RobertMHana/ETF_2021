

/***************************** Include Files *******************************/
#include "CustomCounter_with_interrupt.h"

/************************** Function Definitions ***************************/
